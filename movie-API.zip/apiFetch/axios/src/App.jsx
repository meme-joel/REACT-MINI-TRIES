import { useEffect, useState } from 'react'
import axios from 'axios'
import './App.css'

function App() {
  const key="http://www.omdbapi.com/?s=don&apikey=(add-ur-key-here)"  //add your key by generating key get in omdbapi
  const[datas,setdata]=useState([])
  const fetch=async()=>{
    try{
      const value=await axios.get(key);
      console.log(value.data);
      setdata(value.data.Search)
    }catch(error){
      console.log(error)
    }
  }
  useEffect(()=>{fetch()},[])

  return (
    <>
        <div className="miss">
            
          {
        datas.map((e,index)=>
          (
            
              <div className="card" key={index} >
                <ol>
                   <li><h4>{e.Title}</h4></li> 
                 <li ><img src={e.Poster} alt="img" /></li>
                </ol>
              </div>
           
          )
        )
      }
       </div>
        
          
    
        
    </>
  )
}

export default App
