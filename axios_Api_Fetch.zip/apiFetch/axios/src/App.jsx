import { useEffect, useState } from 'react'
import axios from 'axios'
import './App.css'

function App() {
  const[datas,setdata]=useState([])
  const fetch=async()=>{
    try{
      const value=await axios.get("http://www.omdbapi.com/?s=don&apikey=542636ea");
      console.log(value.data);
      setdata(value.data.Search)
    }catch(error){
      console.log(error)
    }
  }
  useEffect(()=>{fetch()},[])

  return (
    <>
        <div className="miss">
            
          {
        datas.map((e,index)=>
          (
            
              <div className="card" key={index} >
                <ol>
                   <li><h4>{e.Title}</h4></li> 
                 <li ><img src={e.Poster} alt="img" /></li>
                </ol>
              </div>
           
          )
        )
      }
       </div>
        
          
    
        
    </>
  )
}

export default App
